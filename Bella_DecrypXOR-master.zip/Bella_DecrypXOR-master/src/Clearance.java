public enum Clearance {
    Unclassified,
    Confidential,
    Secret,
    Top_Secret
}
