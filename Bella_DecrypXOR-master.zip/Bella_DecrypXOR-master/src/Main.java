public class Main {

    public static void main(String[] args) {
        System.out.println("Decrypt the Top Secret message ");
        System.out.println(" ");
        App app = new App();
        app.app();





    }
}
