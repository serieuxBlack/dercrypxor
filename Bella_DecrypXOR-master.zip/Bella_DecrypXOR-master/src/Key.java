public class Key {
    public static void error() throws invalidException{
        throw new invalidException("The key entered is incorrect");
    }
}
