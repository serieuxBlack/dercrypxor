public class invalidException extends Exception{
    public invalidException(String e){
        super(e);
        System.out.println(e);
    }
}
