public enum Assigner {
    Alpha,
    Bravo,
    Charlie,
    Delta
}
