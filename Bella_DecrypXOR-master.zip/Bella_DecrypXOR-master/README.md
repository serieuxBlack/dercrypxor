# Bella_DecrypXOR
MADE FOR REVATURE PRO BY E.J. Sanchez
(Showcases Java's features) 
Bell-LaPadula Security Model
XOR & RO13 Encryption and Decryption


* Must use 4 Pillars of OOP
* Must create and use at least 3 Constructors
* Must have at least 4 methods
* Must include a section to get responses from User
* Must contain a switch statement
* Must handle at least 1 exception
* Project must include at least 3 Classes
* Must use one of the Collections structures.
* Must use a loop to traverse through your Collection structure that you chose and modify, organize, or return values from the iteration. 
ex. Sort my structure, Search, find and return object


Decrypt the Top Secret message
* 'quit' -- To exit the program"
* 'who' -- To view users and privileges"
* 'login' -- To sign in and view messages, type a number associated with the user" +
* 'decrypt' -- To decrypt a message"
* 'access' -- To view who has access to what"


